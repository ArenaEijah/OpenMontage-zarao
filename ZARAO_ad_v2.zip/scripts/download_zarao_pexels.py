#!/usr/bin/env python3
"""Download the ZARAO ad B-roll from Pexels.
Requires: PEXELS_API_KEY environment variable.
The queries intentionally prefer Madagascar/Antananarivo first; if no result,
the script falls back to broader footage.
"""
import os, sys, requests
from pathlib import Path

KEY=os.environ.get("PEXELS_API_KEY")
if not KEY:
    raise SystemExit("PEXELS_API_KEY n'est pas défini.")

OUT=Path("assets/pexels")
OUT.mkdir(parents=True, exist_ok=True)
jobs=[
 ("01-problem.mp4", ["Madagascar Antananarivo people phone", "people using smartphone group"]),
 ("02-phone.mp4", ["Madagascar smartphone taxi", "woman using phone taxi"]),
 ("03-group.mp4", ["Madagascar friends group", "friends walking together"]),
 ("04-taxi.mp4", ["Madagascar taxi Antananarivo", "taxi passenger"]),
 ("05-travel.mp4", ["Madagascar friends travel", "friends adventure trip"]),
 ("06-market.mp4", ["Madagascar market Antananarivo", "local market people"]),
 ("07-result.mp4", ["Madagascar friends smiling group", "friends conversation"]),
]
H={"Authorization":KEY}

def search(q):
    r=requests.get("https://api.pexels.com/videos/search",
                   headers=H, params={"query":q,"per_page":8,"orientation":"portrait"}, timeout=30)
    r.raise_for_status()
    return r.json().get("videos",[])

def download(video, dest):
    files=video.get("video_files",[])
    files=sorted(files,key=lambda x:(x.get("width",0)*x.get("height",0)),reverse=True)
    f=next((x for x in files if x.get("quality")=="hd"), files[0] if files else None)
    if not f: raise RuntimeError("Aucun fichier vidéo téléchargeable.")
    rr=requests.get(f["link"],timeout=180); rr.raise_for_status()
    dest.write_bytes(rr.content)
    return video.get("url",""), video.get("id"), f.get("width"), f.get("height")

for filename,queries in jobs:
    dest=OUT/filename
    if dest.exists() and dest.stat().st_size>100000:
        print("OK déjà présent:",dest); continue
    chosen=None
    for q in queries:
        videos=search(q)
        if videos:
            chosen=videos[0]
            break
    if not chosen:
        print("Aucun résultat pour",filename,file=sys.stderr); continue
    meta=download(chosen,dest)
    print(filename, "=>", meta)

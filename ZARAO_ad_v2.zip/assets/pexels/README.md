# Plans Pexels

Fichiers attendus :
- `01-problem.mp4`
- `02-phone.mp4`
- `03-group.mp4`
- `04-taxi.mp4`
- `05-travel.mp4`
- `06-market.mp4`
- `07-result.mp4`

Recherche manuelle Pexels :
- https://www.pexels.com/search/videos/madagascar/
- https://www.pexels.com/search/antananarivo/

Le script fourni dans `scripts/download_zarao_pexels.py` utilise l'API Pexels et cherche Madagascar/Antananarivo en priorité.

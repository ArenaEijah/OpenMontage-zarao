# ZARAO Ad V2

Cette V2 utilise **la composition `Explainer` déjà présente dans le dépôt** et son support existant de `screenshot_scene`.

## 1. Copier les fichiers
Copier :
- `remotion-composer/public/zarao-ad/ui-create-share.svg`
- `remotion-composer/public/zarao-ad/ui-tracking.svg`
- `remotion-composer/public/zarao-ad/zarao-ad-v2.json`
- `scripts/download_zarao_pexels.py`

## 2. Télécharger les vrais plans
Dans Codespaces :

```bash
export PEXELS_API_KEY="TA_CLE_PEXELS"
python scripts/download_zarao_pexels.py
```

Le script cherche **Madagascar/Antananarivo en premier**, puis utilise un plan générique seulement si aucun résultat n'est trouvé.

Pexels confirme que les vidéos sont proposées en téléchargement gratuit ; vérifie toujours la licence et les éventuels droits liés aux personnes/marques visibles avant publication commerciale.

## 3. Rendu vertical
Le projet contient déjà `Explainer`. Le JSON V2 est prévu pour un rendu **1080x1920, 30 fps, 45 s**.

Selon la commande de rendu de ton projet, passe les props du fichier :
`remotion-composer/public/zarao-ad/zarao-ad-v2.json`

Exemple Remotion CLI :

```bash
npx remotion render Explainer out/zarao-ad-v2.mp4 --props=remotion-composer/public/zarao-ad/zarao-ad-v2.json --width=1080 --height=1920
```

Si ton `render_demo.py` impose une autre commande, garde simplement ce fichier JSON comme source de props.

## Important — logo
Je n'ai **pas recréé ni redessiné le logo**. La scène finale de production doit continuer à utiliser `assets/logo.png` du dépôt pour conserver exactement le logo officiel.

## Ce qui est nouveau dans V2
- véritable séquence publicitaire 45 s ;
- deux écrans ZARAO réalistes et animés ;
- création d'un partage ;
- suivi `3 / 5` des participants ayant payé ;
- conversation intégrée ;
- plans B-roll ;
- structure verticale 9:16 ;
- recherche Pexels orientée Madagascar.
